# Workflow 1
cd ~/working_directory
ls -lrt
mothur "#make.file(inputdir=., type=gz, prefix=stability)"
mothur "#make.contigs(file=stability.files, maxambig=0, minlength=250, maxlength=550, maxhomop=8)"
mothur "#unique.seqs(fasta=stability.trim.contigs.fasta, count=stability.contigs.count_table)"
mothur "#summary.seqs(fasta=stability.trim.contigs.unique.fasta, count=stability.trim.contigs.count_table)"
# Workflow 2
mothur "#align.seqs(fasta=stability.trim.contigs.unique.fasta, reference=/home/rstudio/database/silva.v34.fasta)"
mothur "#summary.seqs(fasta=stability.trim.contigs.unique.align, count=stability.trim.contigs.count_table)"
mothur "#screen.seqs(fasta=stability.trim.contigs.unique.align, count=stability.trim.contigs.count_table,start=1,end=18929)"
mothur "#filter.seqs(fasta=stability.trim.contigs.unique.good.align, vertical=T, trump=.)"
mothur "#unique.seqs(fasta=stability.trim.contigs.unique.good.filter.fasta, count=stability.trim.contigs.good.count_table)"
# Workflow 3
mothur "#pre.cluster(fasta=stability.trim.contigs.unique.good.filter.unique.fasta, count=stability.trim.contigs.unique.good.filter.count_table, diffs=4)"
mothur "#chimera.vsearch(fasta=stability.trim.contigs.unique.good.filter.unique.precluster.fasta, count=stability.trim.contigs.unique.good.filter.unique.precluster.count_table, dereplicate=t)"
mothur "#classify.seqs(fasta=stability.trim.contigs.unique.good.filter.unique.precluster.denovo.vsearch.fasta, count=stability.trim.contigs.unique.good.filter.unique.precluster.denovo.vsearch.count_table, reference=/home/rstudio/database/trainset9_032012.pds.fasta, taxonomy=/home/rstudio/database/trainset9_032012.pds.tax)"
# Workflow 4
mothur "#remove.lineage(fasta=stability.trim.contigs.unique.good.filter.unique.precluster.denovo.vsearch.fasta, count=stability.trim.contigs.unique.good.filter.unique.precluster.denovo.vsearch.count_table, taxonomy=stability.trim.contigs.unique.good.filter.unique.precluster.denovo.vsearch.pds.wang.taxonomy, taxon=Chloroplast-Mitochondria-unknown-Archaea-Eukaryota)"
mothur "#summary.tax(taxonomy=stability.trim.contigs.unique.good.filter.unique.precluster.denovo.vsearch.pds.wang.pick.taxonomy, count=stability.trim.contigs.unique.good.filter.unique.precluster.denovo.vsearch.pick.count_table)"
mothur "#rename.file(fasta=stability.trim.contigs.unique.good.filter.unique.precluster.denovo.vsearch.pick.fasta, count=stability.trim.contigs.unique.good.filter.unique.precluster.denovo.vsearch.pick.count_table, taxonomy=stability.trim.contigs.unique.good.filter.unique.precluster.denovo.vsearch.pds.wang.pick.taxonomy, prefix=final)"


###PART 2
mothur "#dist.seqs(fasta=final.fasta, cutoff=0.03)"
mothur "#cluster(column=final.dist, count=final.count_table, cutoff=0.03)"
mothur "#classify.otu(list=final.opti_mcc.list, count=final.count_table, taxonomy=final.taxonomy, probs=F, label=0.03)"
mothur "#make.shared(list=final.opti_mcc.list, count=final.count_table, label=0.03)"
##Rarefaction
mothur "#rarefaction.single(shared=final.opti_mcc.shared, freq=1000)"
mothur "#count.groups(shared=final.opti_mcc.shared)"
mothur "#sub.sample(size=10449, list=final.opti_mcc.list, count=final.count_table, taxonomy=final.taxonomy, persample=t)"
mothur "#count.groups(count=final.subsample.count_table)"
##Alpha Diversity
mothur "#classify.otu(list=final.opti_mcc.0.03.subsample.list, count=final.subsample.count_table, taxonomy=final.subsample.taxonomy, label=0.03, probs=F)"
mothur "#make.shared(list=final.opti_mcc.0.03.subsample.list, count=final.subsample.count_table, label=0.03)"
mothur "#summary.single(shared=final.opti_mcc.0.03.subsample.shared,calc=nseqs-coverage-sobs-invsimpson-chao-ace-shannon)"
##Beta Diversity
mothur "#dist.shared(shared=final.opti_mcc.0.03.subsample.shared, calc=braycurtis)"
mothur "#nmds(phylip=final.opti_mcc.0.03.subsample.braycurtis.0.03.lt.dist)"
mothur "#amova(phylip=final.opti_mcc.0.03.subsample.braycurtis.0.03.lt.dist, design=design.files)"
## Phylotype manual
mothur "#phylotype(count=final.subsample.count_table,taxonomy=final.subsample.taxonomy,label=5)"
mothur "#classify.otu(list=final.subsample.tx.list, count= final.subsample.count_table, taxonomy= final.subsample.taxonomy, probs=F)"
mothur "#make.shared(list= final.subsample.tx.list, count= final.subsample.count_table)"
mothur "#system(mv final.subsample.tx.shared final.5.shared)"

## using batch script for phylotype
mothur phylotype.batch

## Advanced Analysis
mothur "#lefse(shared=final.1.shared, design=design.files)"
mothur "#otu.association(shared=final.1.shared, metadata=metadata.tsv, method=spearman)"
mothur "#get.communitytype(shared=final.1.shared, method=pam)"

