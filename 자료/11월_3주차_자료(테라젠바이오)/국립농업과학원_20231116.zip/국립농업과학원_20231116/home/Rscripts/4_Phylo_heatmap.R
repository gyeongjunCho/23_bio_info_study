rm(list=ls())
#install.packages("pheatmap")
library(pheatmap)
library(ComplexHeatmap)

taxon_to_heatmap <-function(taxon_level){
  taxon_num_list <- list('Genus' = 1, 'Family' = 2, 'Order' = 3, 'Class' = 4, 'Phylum' = 5)
  abundance_path <- sprintf("final.%s.shared", taxon_num_list[taxon_level])
  taxon_data_path <-sprintf("final.subsample.tx.%s.cons.taxonomy", taxon_num_list[taxon_level])
  abundance_ori_data <- read.delim(abundance_path, sep = "\t", header = TRUE, row.names = 2)
  taxon_data <- read.delim(taxon_data_path, sep = "\t", header = TRUE, row.names = 1)
  abundance_data <- abundance_ori_data[,3:ncol(abundance_ori_data)]
  
  # change name into taxon
  new_col_list <- list()
  for(col in colnames(abundance_data)){
    taxon_split <- strsplit(taxon_data[col, 'Taxonomy'], ";")[[1]]
    target_taxon <- taxon_split[7 - as.integer(taxon_num_list[taxon_level])]#length(taxon_split)]
    new_col_list <- c(new_col_list, list(target_taxon))
  }
  colnames(abundance_data) <- new_col_list
  
  # remove taxon with abundacne less than 1%
  sample_tot = rowSums(abundance_data)[rownames(abundance_data)[1]]
  abundance_norm_data <- abundance_data / sample_tot * 100
  abundance_norm_data[abundance_norm_data < 1] <- 0
  abundance_norm_data <- abundance_norm_data[, colSums(abundance_norm_data)!=0]
  # log2 normalization
  abundance_log2_norm_data <- apply(abundance_data, 2, function(x) log2(x + 1))
  # transpose()
  abundance_log2_norm_data <- t(abundance_log2_norm_data)
  
  return(abundance_log2_norm_data)
}

group_data <- read.delim("design.files", sep = "\t", header = TRUE,row.names = 1)


# heatmap for each taxonomoc level
taxon_level = 'Phylum'
pheatmap(taxon_to_heatmap(taxon_level), annotation_col = group_data,
         column_split = group_data$type,
         col = colorRampPalette(c("#50388B", "white","firebrick3"))(50), border_color = "black"
         )

taxon_level = 'Class'
pheatmap(taxon_to_heatmap(taxon_level), annotation_col = group_data,
         column_split = group_data$type,
         col = colorRampPalette(c("#50388B", "white","firebrick3"))(50), border_color = "black"
)

taxon_level = 'Order'
pheatmap(taxon_to_heatmap(taxon_level), annotation_col = group_data,
         column_split = group_data$type,
         col = colorRampPalette(c("#50388B", "white","firebrick3"))(50), border_color = "black"
)

taxon_level = 'Family'
pheatmap(taxon_to_heatmap(taxon_level), annotation_col = group_data,
         column_split = group_data$type,
         col = colorRampPalette(c("#50388B", "white","firebrick3"))(50), border_color = "black"
)

taxon_level = 'Genus'
pheatmap(taxon_to_heatmap(taxon_level), annotation_col = group_data,
         column_split = group_data$type,
         col = colorRampPalette(c("#50388B", "white","firebrick3"))(50), border_color = "black"
)

data<-as.data.frame(taxon_to_heatmap('Genus'))
data$Mean <- apply(data, 1, mean)
data <- data[which(data[,"Mean"]>=3),]
data<-as.matrix(data[,c(-11)])

pheatmap(data, annotation_col = group_data,
         column_split = group_data$type,
         col = colorRampPalette(c("#50388B", "white","firebrick3"))(50), border_color = "black"
)

taxon_to_heatmap('Genus') #'Phylum','Class','Order','Family','Genus'

