rm(list=ls())
dev.off()
par_default<-par()

library(visNetwork)
library(geomnet)
library(igraph)
library(data.table)
library(dplyr)

data <- read.table("final.2.2.spearman.otu.corr", header = TRUE,fill=T)
taxonomy<-read.table('final.subsample.tx.2.cons.taxonomy', header=T,sep="\t")

get_last_taxon <- function(taxonomy) {
  splitted <- strsplit(taxonomy, ";")
  last_taxon <- sapply(splitted, function(x) tail(x, n =1))
  return(last_taxon)
}

genus<-get_last_taxon(taxonomy[,3])
taxonomy$Taxonomy<-genus
taxonomy<-taxonomy[,-2]
colnames(taxonomy)<-c("OTUA","Taxonomy")
taxonomy2<-taxonomy
colnames(taxonomy2)<-c("OTUB","Taxonomy2")
merge<- inner_join(data,taxonomy,by="OTUA")
merge2<- inner_join(merge,taxonomy2,by="OTUB")

table<- merge2[,c(5,6,3,4)]

table <- table[which(table[,"Significance"]<=0.05),]
PO <-  table[which(table[,"spearmanCoef"]>=0),]
NG <-  table[which(table[,"spearmanCoef"]<=0),]
NG$spearmanCoef<-NG$spearmanCoef*-1

####
edges<- PO
#edges<- NG

edges<-edges[,c(1,2,3)]
colnames(edges)<-c("from","to","width")
combined_values <- union(edges$from, edges$to)
new_df <- data.frame(combined_values)
new_df[,c(1,2)] <-combined_values
colnames(new_df)<-c("id","label")
nodes<- new_df

graph <- graph_from_data_frame(edges, directed = FALSE)

#Louvain Comunity Detection
cluster <- cluster_louvain(graph)
cluster_df <- data.frame(as.list(membership(cluster)))
cluster_df <- as.data.frame(t(cluster_df))
cluster_df$label <- rownames(cluster_df)
#Create group column
nodes <- left_join(nodes, cluster_df, by = "label")
colnames(nodes)[3] <- "group"
edges$width<- edges$width*3

visNetwork(nodes, edges)%>%
  visPhysics(enabled = F)



