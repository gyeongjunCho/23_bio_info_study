rm(list=ls())
library(ggplot2)

data <- read.table("final.1.1.lefse_summary", header = TRUE,fill=T)
taxonomy<-read.table('final.subsample.tx.1.cons.taxonomy', header=T,sep="\t")

get_last_taxon <- function(taxonomy) {
  splitted <- strsplit(taxonomy, ";")
  last_taxon <- sapply(splitted, function(x) tail(x, n =1))
  return(last_taxon)
}

data$OTU<-get_last_taxon(taxonomy[,3])
data <- data[!is.na(data$LDA), ]
data <- data[order(data[, 3]), ]
data$no <- 1:nrow(data)
##LDA 값 2 이상 추출
data <- data[which(data[,"LDA"]>=2),]
data$LDA <- ifelse(data$Class == "Normal", -data$LDA, data$LDA)
data

Lefse <-ggplot(data, aes(x = LDA, y = reorder(OTU, -no), fill = Class)) +
  geom_bar(stat = "identity", color = "black") +
  #scale_fill_manual(values = c("AD" = "darkgreen", "Normal" = "red")) + #Group별 색 지정
  labs(x = "LDA", y = "OTU", title = "LDA score") +
  theme(plot.title = element_text(size = 18, hjust = 0.5))+
  theme_minimal() +scale_x_continuous(breaks = seq(-4, 4, by = 1), limits = c(-5,5))

Lefse

