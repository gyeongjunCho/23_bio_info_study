rm(list=ls())
library(ggplot2)
library(plotly)
library(ggpubr)
library(ggrepel)


#Table call
nmds<-read.table(file="final.opti_mcc.0.03.subsample.braycurtis.0.03.lt.nmds.axes", header=T,row.names=1)
des<-read.table('design.files', header=T,sep="\t")

#Column name Change & Type name Attatching
colnames(nmds) <- c("MDS1", "MDS2")
MDS <- cbind(nmds, des)

#NMDS Plotting
NMDS<-ggscatter(MDS, x = 'MDS1', y = 'MDS2', color = "type", label = rownames(MDS),
          ellipse = TRUE, check_overlap=F, mean.point=F, star.plot=F, ellipse.level= 0.6)+  coord_fixed(ratio=0.8)+
  theme(panel.background = element_rect(fill = NA, colour = "black", size =1, linetype = "solid"),
        legend.position="right",
        legend.box.background = element_rect(color="black", size=1))

##plotting
NMDS
ggplotly(NMDS)

############################################################################################################################


#######get.communitytypes.
nmds<-read.table(file="final.opti_mcc.0.03.subsample.braycurtis.0.03.lt.nmds.axes", header=T,row.names=1)
des<-read.table('final.1.1.pam.mix.design', header=F,sep="\t")
colnames(des)<-c("Group","type")

#Column name Change & Type name Attatching
colnames(nmds) <- c("MDS1", "MDS2")
MDS <- cbind(nmds, des)

#NMDS Plotting
NMDS<-ggscatter(MDS, x = 'MDS1', y = 'MDS2', color = "type", label = rownames(MDS),
          ellipse = TRUE, check_overlap=F, mean.point=F, star.plot=F, ellipse.level= 0.6)+  coord_fixed(ratio=0.8)+
  theme(panel.background = element_rect(fill = NA, colour = "black", size =1, linetype = "solid"),
        legend.position="right",
        legend.box.background = element_rect(color="black", size=1))
NMDS

