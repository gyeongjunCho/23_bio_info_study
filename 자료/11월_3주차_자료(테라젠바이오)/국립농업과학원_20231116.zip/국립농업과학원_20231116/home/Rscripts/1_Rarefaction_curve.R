rm(list=ls())
#install.packages("plotly")
#install.packages("ggplot2")
#install.packages("reshape2")
library(plotly)
library(ggplot2)
library(reshape2)


data <- read.delim("final.opti_mcc.groups.rarefaction", sep = "\t", header = TRUE, row.names = 1)

# select columns with "0.03"
selected_cols <- grep("0.03", names(data), value = TRUE)
subset_data <- data[, selected_cols]

# remove prefix from column names
new_colnames <- substring(colnames(subset_data), 7)
colnames(subset_data) <- new_colnames

# add index from previous data
subset_data['index'] = as.integer(rownames(subset_data))

data_melt <- melt(subset_data, id.vars = c("index"))
data_melt<-na.omit(data_melt)
colnames(data_melt) <- c('Sample_size', 'Sample', 'Species')
g <-ggplot(data = data_melt, aes(x = Sample_size, y = Species, group = Sample)) +
  geom_line(aes(color = Sample)) +
  xlab("Sample size") +
  ylab("Species") +
  ggtitle("Rarefaction Curve") +
  scale_y_log10()
ggplotly(g)


