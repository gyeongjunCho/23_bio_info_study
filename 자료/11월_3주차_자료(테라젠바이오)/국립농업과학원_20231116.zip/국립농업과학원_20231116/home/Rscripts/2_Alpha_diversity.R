rm(list=ls())
library(ggplot2)
library('ggsignif')
library(plotly)
library(ggpubr)
library(reshape2)

# load data
ad_table <- read.delim('final.opti_mcc.0.03.subsample.groups.summary', sep = "\t", header = TRUE, row.names = 2)
ad_table <- ad_table[,2:ncol(ad_table)]

group_data <- read.delim("design.files", sep = "\t", header = TRUE, row.names = 1)
ad_table <- ad_table[,c(3,7,13,10)]
ad_table['Group'] <- group_data['type']

ad_melt <- melt(ad_table, id.vars = c("Group"))

# draw boxplot
g <-ggplot(ad_melt, aes(x = Group, y = value),title="Alpha Diversity") +
  geom_boxplot(aes(fill = Group)) +
  facet_wrap(~ variable, scales = "free_y", ncol = 9) +
  xlab("") +
  ylab("") +
  theme_bw() +
  # p-value
  stat_compare_means(method = "wilcox.test", label.x.npc = "left")
g
ggplotly(g)
